/* by Tyler Davidson
 *
 * Repeating Decimals:		NONTRIVIAL		(Arithmetic)
 *
 * This algorithm uses long division to find the answer, keeping track of the
 * remainders--both how often their used, and where they are in relation to
 * the decimal number. When the same remainder is used more than once, a cycle
 * has been found.
 */

#include <cstdio>
#include <iostream>
#include <map>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

int longDivision(const int numer, const int denom)
{
	int num = numer, den = denom;
	int dig, rem;
	map<int, int> remainders;
	vector<int> remPos;
	string result;
	stringstream ss;

	dig = numer/denom;
	rem = numer % denom;
	ss << dig << ".";
	remPos.push_back(rem);
	remainders.insert(pair<int,int>(rem, 1));
	while (remainders[rem] < 2)
	{
		num = rem * 10;
		dig = num / den;
		rem = num % den;

		remPos.push_back(rem);
		if (remainders.find(rem) == remainders.end())
			remainders.insert(pair<int,int>(rem, 1));
		else
			remainders[rem] += 1;
		ss << dig;
	}
	result = ss.str();
	// find decimal
	size_t pos = result.find_first_of(".");
	size_t i;
	for (i = 0; remPos[i] != rem; ++i);
	int openPos = i+pos+1;
	int len = result.size() - openPos;
	result.insert(openPos, "(");
	if (len > 50)
		result.replace(openPos+50+1, result.size(), "...");
	result.push_back(')');
	cout << result << endl;
	return len;
}

int main()
{
	int numer, denom;

	while(scanf("%d %d", &numer, &denom) == 2){
		int num;

		printf("%d/%d = ", numer, denom);
		num = longDivision(numer, denom);
		printf("   %d = number of digits in repeating cycle\n\n", num);
	}

	return 0;
}
