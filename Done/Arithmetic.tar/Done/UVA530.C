/* by Tyler Davidson
 *
 * Binomial Showdown: 	NONTRIVIAL		(Arithmetic)
 *
 * This is an n choose k problem. Using the formula n!/k!(n-k)!, this eliminates
 * the (n-k)! term from both the numerator and the denominator, then does the
 * division.
 */

#include <cstdio>
#include <iostream>

#define ll long long

using namespace std;

int n, k;

int main()
{
	scanf("%d %d", &n, &k);
	while (1){
		if ((n == 0) && (k == 0)) break;
		if ((n == k) || (k == 0)){
			printf("1\n");
			scanf("%d %d", &n, &k);
			continue;
		}

		double num = 1;

		if (n-k < k) k = n - k;

        for (int i = n; i > n - k; --i)
        	num *= i;
        for (int i = k; i > 1; --i)
        	num /= i;

        printf("%.0f\n", num);

		scanf("%d %d", &n, &k);
	}

	return 0;
}
