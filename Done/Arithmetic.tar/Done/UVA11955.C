/* by Tyler Davidson
 *
 * Binomial Theorem: 	(Arithmetic)
 *
 * This program uses a very simple algorithm. It uses Pascal's triangle to find
 * the coefficients for each term, and a simple loop to find exponents.
 */

#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <string>

#define ll long long

using namespace std;

int T, k;
string a, b;

void getPower()
{
	getchar();
	scanf("%d", &k);
}

void getBinomial()
{
	char x;
	while ((x = getchar()) != '+')
		a.push_back(x);
	while ((x = getchar()) != ')')
		b.push_back(x);
}

void printB(const int exp)
{
	if (exp == 1)
		cout << b;
	else
		cout << b << "^" << exp;
}

void printA(const int exp)
{
	if (exp == 1)
		cout << a;
	else
		cout << a << "^" << exp;
}

int main()
{
	int caseNum = 1;
	scanf("%d", &T);
	for (int i = 0; i < T; ++i){
		ll coef = 1;
		while (getchar() != '(');		// discard open bracket
		getBinomial();
		getPower();

		cout << "Case " << caseNum << ": ";
		if (k == 1)
			cout << a << "+" << b << endl;
		else{
			cout << a << "^" << k;
			for (int i = 0; i < k; ++i){
				int exp = k-i;
				coef = coef * (k - i) / (i + 1); // from Pascal's Triangle
				if(coef > 1){
					cout << "+" << coef << "*";

					printA(exp - 1);
					cout << "*";
					printB(i + 1);
				}
			}
			cout << "+" << b << "^" << k << endl;
		}

		caseNum += 1;
		a.clear(); b.clear();
	}
	return 0;
}
