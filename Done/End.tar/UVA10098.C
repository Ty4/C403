/* by Tyler Davidson
 *
 * Generating Fast: 	(Recursion)
 *
*/

#include <iostream>
#include <algorithm>

using namespace std;


int main()
{
	int testCases;
	string line;

	cin >> testCases;
	while (testCases--){
		cin >> line;

		sort(line.begin(),line.end());
		do{
			cout << line << endl;
		} while(next_permutation(line.begin(),line.end()));
		cout << endl;
	}
	return 0;
}
